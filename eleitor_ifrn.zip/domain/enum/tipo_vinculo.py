from enum import IntEnum

class TipoVinculo(IntEnum):
    DISCENTE = 1
    DOCENTE = 2