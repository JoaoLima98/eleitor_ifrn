from enum import IntEnum

class Status(IntEnum):
    ATIVO = 1
    INATIVO = 2
    SUSPENSO = 3